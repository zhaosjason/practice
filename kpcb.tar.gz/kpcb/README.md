# KCPB Fellows Coding Challenge: HashMap
Written in C by Jason Zhao.  9/30/2016.  Source also available on [github](https://github.com/zhaosjason/practice/tree/master/kpcb).

### Running
Type `make` to build and `./main` to run the sanity check.  To run your own tests on the hashmap, simply `#include "hashmap.h"` in your test file.

